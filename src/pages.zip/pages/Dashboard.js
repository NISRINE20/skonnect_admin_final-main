// src/pages/Dashboard.js
import React, { useEffect, useState } from 'react';
import {
  FaArrowUp,
  FaArrowDown,
  FaCalendarAlt,
  FaClock,
  FaMapMarkerAlt,
  FaUsers,
  FaSearch,
  FaChevronLeft,
  FaChevronRight,
  FaBell
} from 'react-icons/fa';
import {
  Container,
  Main,
  Topbar,
  TopIcons,
  Profile,
  DashboardTitle,
  Grid,
  Card,
  DescriptionModalOverlay,
  DescriptionModalContent,
  DescriptionModalTitle,
  ModalButton,
  DescriptionCell,
  SeeMoreButton,
  TableWrapper,
  StyledTable,
  ActionButtons
} from '../styles/DashboardStyles';
import Sidebar from '../components/Sidebar';
import styled, { createGlobalStyle } from 'styled-components';
import logo from '../sk.png';

const GlobalStyle = createGlobalStyle`
  body, #root {
    background: ${({ dark }) => (dark ? '#18181b' : '#f3f5f9')};
    color: ${({ dark }) => (dark ? '#f3f5f9' : '#18181b')};
    transition: background 0.3s, color 0.3s;
  }
`;

const EventList = styled.div`
  margin-top: 2rem;
`;

const EventCard = styled.div`
  background: white;
  border-radius: 0.75rem;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
`;

// Base modal container for participants, attendance, and activities
const ParticipantModal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2000;
  overflow-y: auto;
`;

const EventInfo = styled.div`
  flex: 1;
`;

const IconText = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #64748b;
  margin: 0.25rem 0;
  font-size: 0.875rem;
`;

const NotificationButton = styled.button`
  position: fixed;
  top: 1rem;
  right: 1rem;
  z-index: 4000;
  background: white;
  color: #111827;
  border: none;
  padding: 0.5rem 0.6rem;
  border-radius: 0.5rem;
  box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1.05rem;

  &:hover {
    background: #f3f4f6;
  }
`;

const NotificationBadge = styled.span`
  position: absolute;
  top: -6px;
  right: -6px;
  background: #dc2626;
  color: white;
  font-size: 0.65rem;
  font-weight: 700;
  width: 1.2rem;
  height: 1.2rem;
  border-radius: 9999px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StatusBadge = styled.span`
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
  margin-left: 0.75rem;
  background: ${({ status }) => (status === 'upcoming' ? '#dcfce7' : '#fee2e2')};
  color: ${({ status }) => (status === 'upcoming' ? '#166534' : '#991b1b')};
`;

const Button = styled.button`
  background: #2563eb;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  &:hover { background: #1d4ed8; }
`;

const SearchBar = styled.input`
  padding: 0.5rem 1rem;
  margin-bottom: 1.5rem;
  border: 1px solid #d1d5db;
  border-radius: 0.5rem;
  font-size: 1rem;
  width: 100%;
  max-width: 350px;
  display: block;
`;

const Table = styled.table`
  width: 100%;
  background: white;
  border-collapse: collapse;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`;

const Thead = styled.thead`
  background: #3b82f6;
  color: white;

  th {
    padding: 0.75rem;
    font-size: 0.875rem;
    text-align: left;
    font-weight: 600;
  }
`;

const Tbody = styled.tbody`
  tr {
    border-bottom: 1px solid #e5e7eb;

    &:hover {
      background: #f9fafb;
    }
  }

  td {
    padding: 0.75rem;
    font-size: 0.875rem;
    color: #374151;
  }
`;

// New: modal variant that appears above the activities modal
const TopModal = styled(ParticipantModal)`
  z-index: 3000;
`;

const ModalContent = styled.div`
  background: white;
  padding: 2rem;
  border-radius: 0.75rem;
  width: 90%;
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
`;

const ModalTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 700;
  color: #2563eb;
  margin-bottom: 1.5rem;
  padding-bottom: 0.75rem;
  border-bottom: 2px solid #e2e8f0;
`;

const ParticipantCard = styled.div`
  padding: 1rem;
  border-radius: 0.5rem;
  background: #f8fafc;
  margin-bottom: 0.75rem;
  border: 1px solid #e2e8f0;
`;

/* ---------- Pagination styled components ---------- */
const PaginationContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
`;

const ArrowButton = styled.button`
  background: #2563eb;
  color: white;
  border: none;
  padding: 0.45rem 0.9rem;
  border-radius: 0.375rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  &:hover:not(:disabled) { background: #1d4ed8; }
  &:disabled { background: #9ca3af; cursor: not-allowed; }
`;

const PageIndicator = styled.span`
  font-size: 0.95rem;
  color: #374151;
  font-weight: 600;
`;

/* ---------- Event filter styled components ---------- */
const FilterBar = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
`;

const FilterButton = styled.button`
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  border: 1px solid #e5e7eb;
  background: ${props => props.active ? '#3b82f6' : 'white'};
  color: ${props => props.active ? 'white' : '#374151'};
  transition: all 0.2s;
  &:hover {
    background: ${props => props.active ? '#2563eb' : '#f9fafb'};
  }
`;

/* ---------- Notification Modal styled components ---------- */
const NotificationModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: flex-end;
  align-items: flex-start;
  z-index: 3500;
  padding-top: 5.5rem;
`;

const NotificationModalBox = styled.div`
  background: white;
  border-radius: 0.75rem;
  width: 90%;
  max-width: 420px;
  max-height: 65vh;
  overflow-y: auto;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  margin-right: 1rem;
  display: flex;
  flex-direction: column;
`;

// Header section of notification modal with title and close button
const NotificationHeader = styled.div`
  padding: 1rem;
  border-bottom: 2px solid #e2e8f0;
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  top: 0;
  z-index: 1;
`;

const NotificationTitle = styled.h3`
  font-size: 1.1rem;
  font-weight: 700;
  color: white;
  margin: 0;
`;

// Close button for the notification modal
const CloseNotificationButton = styled.button`
  background: rgba(255, 255, 255, 0.2);
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 0.375rem;
  transition: background 0.2s;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
  }
`;

// Container for all notification items (scrollable)
const NotificationList = styled.div`
  flex: 1;
  overflow-y: auto;
  
  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-track {
    background: #f1f5f9;
  }
  &::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
    
    &:hover {
      background: #94a3b8;
    }
  }
`;

// Individual notification item (clickable, highlights new comments)
const NotificationItem = styled.div`
  padding: 1rem;
  border-bottom: 1px solid #e2e8f0;
  cursor: pointer;
  transition: all 0.2s;
  /* highlight new notifications with yellow/blue background */
  background: ${props => props.isNew ? 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)' : 'white'};
  border-left: 4px solid ${props => props.isNew ? '#f59e0b' : 'transparent'};

  &:hover {
    background: ${props => props.isNew ? '#fde68a' : '#f9fafb'};
    transform: translateX(4px);
  }

  &:last-child {
    border-bottom: none;
  }
`;

// Title of each notification (user name)
const NotificationItemTitle = styled.p`
  font-size: 0.95rem;
  font-weight: 600;
  color: #1e293b;
  margin: 0 0 0.5rem 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

// Body/content preview of the notification
const NotificationItemBody = styled.p`
  font-size: 0.88rem;
  color: #475569;
  margin: 0 0 0.75rem 0;
  line-height: 1.4;
`;

// Timestamp for when the notification was created
const NotificationItemTime = styled.span`
  font-size: 0.75rem;
  color: #94a3b8;
`;

// Badge showing "New" status for unread notifications
const NotificationBadgeNew = styled.span`
  display: inline-block;
  background: #ef4444;
  color: white;
  font-size: 0.65rem;
  font-weight: 700;
  padding: 0.2rem 0.6rem;
  border-radius: 9999px;
`;

// Empty state message when no notifications exist
const NotificationEmpty = styled.div`
  padding: 3rem 1.5rem;
  text-align: center;
  color: #94a3b8;
  font-size: 0.95rem;
  
  svg {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: #cbd5e1;
  }
`;

// Notification footer with CTA
const NotificationFooter = styled.div`
  padding: 1rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
  text-align: center;
`;

/* ---------- Dashboard component ---------- */
const Dashboard = () => {
  const [youthCount, setYouthCount] = useState(0);
  const [youthIncrease, setYouthIncrease] = useState(0);
  const [eventCount, setEventCount] = useState(0);
  const [eventIncrease, setEventIncrease] = useState(0);
  const [aiUsage, setAiUsage] = useState(0);
  const [aiUsageIncrease, setAiUsageIncrease] = useState(0);
  const [darkMode, setDarkMode] = useState(() => {
  const saved = localStorage.getItem('skonnect_dark_mode');
    return saved === 'true';
  });
  const [engagementCount, setEngagementCount] = useState(0);
  const [engagementIncrease, setEngagementIncrease] = useState(0);
  const [events, setEvents] = useState([]); // Ensure this is initialized as an empty array
  const [searchTerm, setSearchTerm] = useState('');
  const [participantsModal, setParticipantsModal] = useState(false);
  const [selectedEventParticipants, setSelectedEventParticipants] = useState([]);
  const [selectedEventTitle, setSelectedEventTitle] = useState('');
  const [attendanceModal, setAttendanceModal] = useState(false);
  const [selectedEventAttendance, setSelectedEventAttendance] = useState([]);
  const [selectedAttendanceTitle, setSelectedAttendanceTitle] = useState('');
  const [subEventsModal, setSubEventsModal] = useState(false);
  const [selectedEventSubEvents, setSelectedEventSubEvents] = useState([]);
  const [selectedSubEventsTitle, setSelectedSubEventsTitle] = useState('');
  const [descriptionModal, setDescriptionModal] = useState(false);
  const [selectedDescription, setSelectedDescription] = useState('');
  const [selectedDescriptionTitle, setSelectedDescriptionTitle] = useState(''); /* ---------- NEW: Notification modal states ---------- */
  const [notificationModal, setNotificationModal] = useState(false);      // Toggle notification modal visibility
  const [comments, setComments] = useState([]);                            // Array of all comments from API
  const [readCommentIds, setReadCommentIds] = useState(new Set());        // Track which comments have been read
  const [commentsTotal, setCommentsTotal] = useState(0);                   // Total comment count
  const [unreadComments, setUnreadComments] = useState(0);                 // Count of unread comments
  const [commentsInitialLoaded, setCommentsInitialLoaded] = useState(false); // Flag to track initial load

// ===== helper to truncate by characters (define inside component, before return) =====
  const truncateDescription = (text, limit = 100) => {
    if (!text) return '';
    return text.length > limit ? text.substring(0, limit) + '...' : text;
  };


  // Pagination states (you already had this, keeping 6 per page)
  const [currentPage, setCurrentPage] = useState(1);
  const eventsPerPage = 5;

  // NEW: status filter default to 'upcoming'
  const [statusFilter, setStatusFilter] = useState('upcoming');

  useEffect(() => {
    fetch('http://localhost/skonnect-api/youth_count.php')
      .then(res => res.json())
      .then(data => {
        setYouthCount(data.count);
        setYouthIncrease(data.increase_percent);
      })
      .catch(err => {
        setYouthCount(0);
        setYouthIncrease(0);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost/skonnect-api/main_event_count.php')
      .then(res => res.json())
      .then(data => {
        setEventCount(data.count);
        setEventIncrease(data.increase_percent);
      })
      .catch(err => {
        setEventCount(0);
        setEventIncrease(0);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost/skonnect-api/ai_usage.php')
      .then(res => res.json())
      .then(data => {
        setAiUsage(data.total);
        setAiUsageIncrease(data.percent_change);
      })
      .catch(err => {
        setAiUsage(0);
        setAiUsageIncrease(0);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost/skonnect-api/total_engagements.php')
      .then(res => res.json())
      .then(data => {
        setEngagementCount(data.total || 0);
        setEngagementIncrease(typeof data.percent_change !== 'undefined' ? data.percent_change : 0);
      })
      .catch(err => {
        setEngagementCount(0);
        setEngagementIncrease(0);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost/skonnect-api/fetch_main_events.php')
      .then(async res => {
        const text = await res.text();
        try {
          const data = JSON.parse(text);
          if (data.status === 'success' && Array.isArray(data.main_events)) { // Check if the status is success and if main_events is an array
            setEvents(data.main_events); // Set events to the main_events array
          } else {
            console.error("Fetched data is not valid:", data);
            setEvents([]); // Reset to empty array if not valid
          }
        } catch {
          console.error("Invalid JSON from API:", text);
          setEvents([]); // Reset to empty array on error
        }
      })
      .catch(err => {
        console.error("Failed to fetch events", err);
        setEvents([]); // Reset to empty array on fetch error
      });
  }, []);

   useEffect(() => {
    let mounted = true;
    let intervalId = null;

    async function fetchCommentsCount() {
    try {
        const res = await fetch('http://localhost/skonnect-api/get_feedback.php');
        if (!res.ok) throw new Error('Comments fetch failed');
        const data = await res.json();
        const commentsList = Array.isArray(data) ? data : [];

        if (!mounted) return;

        // Update the comments list
        setComments(commentsList);

        const count = commentsList.length;

        // First load: initialize without notifying
        if (!commentsInitialLoaded) {
          setCommentsTotal(count);
          setCommentsInitialLoaded(true);
          return;
        }

        // Subsequent loads: detect new comments
        if (count > commentsTotal) {
          // New comments arrived - increment unread count
          setUnreadComments(prev => prev + (count - commentsTotal));
          setCommentsTotal(count);
        } else {
          // Update total if decreased or unchanged
          setCommentsTotal(count);
        }
      } catch (err) {
        console.error('Error fetching comments:', err);
      }
    }

    // Initial fetch then set up polling interval
    fetchCommentsCount();
    intervalId = setInterval(fetchCommentsCount, 8000); // Poll every 8 seconds

    return () => {
      mounted = false;
      if (intervalId) clearInterval(intervalId);
    };
  }, [commentsTotal, commentsInitialLoaded]);

  useEffect(() => {
    localStorage.setItem('skonnect_dark_mode', darkMode);
  }, [darkMode]);

  // Filter events based on search + status
  const filteredEvents = events.filter(ev => {
    const matchesText = (ev.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ev.description?.toLowerCase().includes(searchTerm.toLowerCase()));
    const evStatus = (ev.status || 'upcoming'); // fallback if DB missing
    const matchesStatus = statusFilter === 'all' ? true : (evStatus === statusFilter);
    return matchesText && matchesStatus;
  });

  // Reset page when filter/search/events change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, events.length, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredEvents.length / eventsPerPage));
  const indexOfLastEvent = currentPage * eventsPerPage;
  const indexOfFirstEvent = indexOfLastEvent - eventsPerPage;
  const currentEvents = filteredEvents.slice(indexOfFirstEvent, indexOfLastEvent);

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1);
  };

  // participants, attendance, sub-events functions
  const handleSeeParticipants = async (subEvent) => {
    try {
      const response = await fetch(`http://localhost/skonnect-api/fetch_event_responses.php?sub_event_id=${subEvent.id}`);
      const data = await response.json();
      setSelectedEventParticipants(data.participants || []);
      setSelectedEventTitle(subEvent.title);
      setParticipantsModal(true);
    } catch (err) {
      console.error('Failed to fetch participants:', err);
    }
  };

  const handleShowAttendance = async (subEvent) => {
    try {
      const id = subEvent?.id ?? 0;
      if (!id) return;

      // Use the new API (supports subevent_id / sub_event_id)
      const res = await fetch(`http://localhost/skonnect-api/fetch_attendance.php?subevent_id=${id}`);
      const data = await res.json();

      if (!data || !data.success) {
        console.error('Failed to fetch attendance', data);
        setSelectedEventAttendance([]);
      } else {
        // Normalize timestamps for display
        const attendance = (data.attendance || []).map(a => ({
          ...a,
          timestamp: a.timestamp ? new Date(a.timestamp).toLocaleString() : null,
          created_at: a.created_at ? new Date(a.created_at).toLocaleString() : null
        }));
        setSelectedEventAttendance(attendance);
      }

      setSelectedAttendanceTitle(subEvent.title || '');
      setAttendanceModal(true);
    } catch (err) {
      console.error('Failed to fetch attendance:', err);
      setSelectedEventAttendance([]);
      setSelectedAttendanceTitle(subEvent?.title || '');
      setAttendanceModal(true);
    }
  };

  // NEW: mark main event as done
  const handleMarkEventDone = async (eventItem) => {
    try {
      const res = await fetch('http://localhost/skonnect-api/update_main_event_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_id: eventItem.id, status: 'done' })
      });
      const data = await res.json();
      if (data && data.success) {
        // update local events state so UI reflects change immediately
        setEvents(prev => prev.map(ev => ev.id === eventItem.id ? { ...ev, status: 'done' } : ev));
      } else {
        console.error('Failed to update event status', data);
      }
    } catch (err) {
      console.error('Error updating event status:', err);
    }
  };

  const handleViewActivities = async (event) => {
    try {
      const response = await fetch(`http://localhost/skonnect-api/get_sub_events.php?event_id=${event.id}`);
      const data = await response.json();
      setSelectedEventSubEvents(data.subevents || []);
      setSelectedSubEventsTitle(event.title);
      setSubEventsModal(true);
    } catch (err) {
      console.error('Failed to fetch sub-events:', err);
    }
  };

  /* ---------- NEW: Handle opening notification modal ---------- */
  const handleOpenNotificationModal = () => {
    setNotificationModal(true);
    setUnreadComments(0); // Clear unread badge when modal opens
  };

  /* ---------- NEW: Handle clicking on a notification item ---------- */
  const handleNotificationClick = (commentId) => {
    // Mark comment as read
    setReadCommentIds(prev => new Set([...prev, commentId]));
    // Close modal and redirect to comments page
    setNotificationModal(false);
    window.location.href = '/comments';
  };

  // Get list of unread comments for badge display
  const unreadCommentsData = comments.filter(c => !readCommentIds.has(c.id));

  return (
    <>
      <GlobalStyle dark={darkMode} />
      <Container style={darkMode ? { background: '#18181b', color: '#f3f5f9' } : {}}>

        {/* ---------- IMPROVED: Notification Modal (opens when bell icon clicked) ---------- */}
        {notificationModal && (
          <NotificationModalOverlay onClick={() => setNotificationModal(false)}>
            <NotificationModalBox onClick={e => e.stopPropagation()}>
              {/* Modal header with title and close button */}
              <NotificationHeader>
                <NotificationTitle>
                  💬 Comments
                </NotificationTitle>
                {/* Close button to dismiss modal */}
                <CloseNotificationButton onClick={() => setNotificationModal(false)}>
                  ✕
                </CloseNotificationButton>
              </NotificationHeader>

              {/* Scrollable list of notifications */}
              <NotificationList>
                {comments.length === 0 ? (
                  // Empty state message
                  <NotificationEmpty>
                    <div style={{ fontSize: '2.5rem' }}>📭</div>
                    <p>No comments yet.</p>
                    <p style={{ fontSize: '0.85rem', marginTop: '0.5rem' }}>
                      When users leave feedback, it will appear here.
                    </p>
                  </NotificationEmpty>
                ) : (
                  // Map through comments and display each as a clickable notification item
                  comments.map(comment => {
                    // Determine if this comment is new (unread)
                    const isNew = !readCommentIds.has(comment.id);
                    // Format timestamp for display
                    const commentTime = comment.created_at 
                      ? new Date(comment.created_at).toLocaleString() 
                      : 'Unknown time';
                    
                    return (
                      <NotificationItem
                        key={comment.id}
                        isNew={isNew}
                        // Clicking on a notification marks it as read and redirects to comments page
                        onClick={() => handleNotificationClick(comment.id)}
                      >
                        {/* Display commenter name with "New" badge if unread */}
                        <NotificationItemTitle>
                          <span>{comment.name || 'Anonymous User'}</span>
                          {isNew && <NotificationBadgeNew>New</NotificationBadgeNew>}
                        </NotificationItemTitle>
                        
                        {/* Display truncated comment preview (first 80 characters) */}
                        <NotificationItemBody>
                          {comment.message 
                            ? comment.message.substring(0, 80) + (comment.message.length > 80 ? '...' : '')
                            : '📝 No message content'
                          }
                        </NotificationItemBody>
                        
                        {/* Display when the comment was created */}
                        <NotificationItemTime>
                          ⏰ {commentTime}
                        </NotificationItemTime>
                      </NotificationItem>
                    );
                  })
                )}
              </NotificationList>

              {/* Footer with call-to-action */}
              {comments.length > 0 && (
                <NotificationFooter>
                  <Button 
                    onClick={() => {
                      setNotificationModal(false);
                      window.location.href = '/comments';
                    }}
                    style={{ width: '100%' }}
                  >
                    View All Comments →
                  </Button>
                </NotificationFooter>
              )}
            </NotificationModalBox>
          </NotificationModalOverlay>
        )}

        <Sidebar darkMode={darkMode} />
        <Main>

        <Topbar>
          <DashboardTitle>
            <h2>Dashboard</h2>
            <p>Hi, Admin. Welcome back to SKonnect Admin!</p>
          </DashboardTitle>

          {/* ---------- IMPROVED: Notification Bell Button (top-right corner) ---------- */}
        <NotificationButton
                 aria-label="Comments notifications"
                 onClick={handleOpenNotificationModal}
                 style={{ position: 'relative' }}
                 title={unreadComments > 0 ? `${unreadComments} new comment(s)` : 'No new comments'}
               >
                 <FaBell />
                 {unreadComments > 0 && (
                   <NotificationBadge>{unreadComments > 99 ? '99+' : unreadComments}</NotificationBadge>
                 )}
        </NotificationButton>

        </Topbar>
        
          <Grid>
            {[
              {
                img: "https://cdn-icons-png.flaticon.com/512/3790/3790347.png",
                value: youthCount,
                label: "Total Youths",
                change: youthIncrease,
                iconUp: <FaArrowUp />,
                iconDown: <FaArrowDown />
              },
              {
                img: "https://static.vecteezy.com/system/resources/previews/016/314/814/original/transparent-event-schedule-icon-free-png.png",
                value: eventCount,
                label: "Total Events",
                change: eventIncrease,
                iconUp: <FaArrowUp />,
                iconDown: <FaArrowDown />
              },
              {
                img: "https://static.vecteezy.com/system/resources/previews/025/729/534/original/esports-fan-engagement-icon-in-illustration-vector.jpg",
                value: engagementCount,
                label: "Total Engagements",
                change: engagementIncrease,
                iconUp: <FaArrowUp />,
                iconDown: <FaArrowDown />
              },
              {
                img: "https://static.vecteezy.com/system/resources/previews/029/453/197/original/ai-and-human-interaction-icon-vector.jpg",
                value: aiUsage,
                label: "AI Interactions",
                change: aiUsageIncrease,
                iconUp: <FaArrowUp />,
                iconDown: <FaArrowDown />
              }
            ].map((card) => (
              <Card key={card.label}>
                <img src={card.img} draggable={false} />
                <div className="details">
                  <h4>{card.value}</h4>
                  <p>{card.label}</p>
                  <div className={`change ${card.change >= 0 ? 'up' : 'down'}`}>
                    {card.change >= 0 ? card.iconUp : card.iconDown}
                    {Math.abs(card.change)}% (30 days)
                  </div>
                </div>
              </Card>
            ))}
          </Grid>

          {/* Add Events List */}
          <EventList>
            <h3 style={{ color: '#1f2937', fontWeight: '700', marginBottom: '1rem' }}>
              📋 Events
            </h3>

            {/* Filter bar: default is "upcoming" */}
            <FilterBar>
              <FilterButton active={statusFilter === 'upcoming'} onClick={() => setStatusFilter('upcoming')}>
                Upcoming
              </FilterButton>
              <FilterButton active={statusFilter === 'done'} onClick={() => setStatusFilter('done')}>
                Done
              </FilterButton>
              <FilterButton active={statusFilter === 'all'} onClick={() => setStatusFilter('all')}>
                All
              </FilterButton>
            </FilterBar>

            <SearchBar
              type="text"
              placeholder="Search events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />

            {filteredEvents.length === 0 ? (
              <p style={{ textAlign: 'center', color: '#64748b', padding: '2rem 0' }}>
                {searchTerm ? 'No events found matching your search.' : 'No events found.'}
              </p>
            ) : (
              <>
                <TableWrapper>
                <StyledTable>
                  <Thead>
                    <tr>
                      <th>Title</th>
                      <th>Description</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </Thead>
                  <Tbody>
                    {currentEvents.map((ev) => (
                      <tr key={ev.id}>
                        <td>{ev.title}</td>
                        <DescriptionCell>
                          {ev.description && ev.description.length > 100 ? (
                            <>
                              {truncateDescription(ev.description, 100)}{' '}
                              <SeeMoreButton
                                onClick={() => {
                                  setSelectedDescription(ev.description);
                                  setSelectedDescriptionTitle(ev.title);
                                  setDescriptionModal(true);
                                }}
                              >
                                See more...
                              </SeeMoreButton>
                            </>
                          ) : (
                            ev.description
                          )}
                        </DescriptionCell>
                        <td>
                          {(ev.status || 'upcoming') === 'upcoming' ? (
                            <StatusBadge status="upcoming">Upcoming</StatusBadge>
                          ) : (
                            <StatusBadge status="done">Done</StatusBadge>
                          )}
                        </td>
                        <td>
                          <ActionButtons>
                            <Button
                              onClick={() => handleViewActivities(ev)}
                              style={{
                                background: '#3b82f6',
                                padding: '0.5rem 1rem',
                                borderRadius: '0.375rem',
                                fontSize: '0.875rem',
                                whiteSpace: 'nowrap'
                              }}
                            >
                              🎯 View Activities
                            </Button>

                            <Button
                              onClick={() => handleMarkEventDone(ev)}
                              style={{
                                background: '#10b981',
                                padding: '0.5rem 1rem',
                                borderRadius: '0.375rem',
                                fontSize: '0.875rem',
                                whiteSpace: 'nowrap'
                              }}
                            >
                              ✅ Done Event
                            </Button>
                          </ActionButtons>
                        </td>
                      </tr>
                    ))}
                  </Tbody>
                </StyledTable>
              </TableWrapper>


                {/* Pagination controls */}
                <PaginationContainer>
                  <ArrowButton onClick={handlePrevPage} disabled={currentPage === 1}>
                    <FaChevronLeft /> Prev
                  </ArrowButton>

                  <PageIndicator>
                    Page {currentPage} of {totalPages}
                  </PageIndicator>

                  <ArrowButton onClick={handleNextPage} disabled={currentPage === totalPages}>
                    Next <FaChevronRight />
                  </ArrowButton>
                </PaginationContainer>
              </>
            )}
          </EventList>

          {/* Participants Modal */}
          {participantsModal && (
            <TopModal onClick={() => setParticipantsModal(false)}>
              <ModalContent onClick={e => e.stopPropagation()}>
                <ModalTitle>👥 Participants - {selectedEventTitle}</ModalTitle>
                {selectedEventParticipants.length === 0 ? (
                  <p style={{ color: '#64748b', textAlign: 'center', margin: '2rem 0' }}>No participants found.</p>
                ) : (
                  selectedEventParticipants.map((p, idx) => (
                    <ParticipantCard key={idx}>
                      <p style={{ marginBottom: 8, color: '#2563eb', fontWeight: 600 }}>
                        <span style={{ color: '#334155' }}><strong>Email:</strong></span> {p.email}
                      </p>
                      {Object.entries(p.responses || {}).map(([label, value]) => (
                        <p key={label} style={{ margin: 0, color: '#334155' }}>
                          <strong>{label}:</strong> {value}
                        </p>
                      ))}
                    </ParticipantCard>
                  ))
                )}
                <Button onClick={() => setParticipantsModal(false)} style={{ marginTop: '1.5rem', width: '100%' }}>
                  Close
                </Button>
              </ModalContent>
            </TopModal>
          )}

          {/* Attendance Modal */}
          {attendanceModal && (
            <TopModal onClick={() => setAttendanceModal(false)}>
              <ModalContent onClick={e => e.stopPropagation()}>
                <ModalTitle>📝 Attendance - {selectedAttendanceTitle}</ModalTitle>
                {selectedEventAttendance.length === 0 ? (
                  <p style={{ color: '#64748b', textAlign: 'center', margin: '2rem 0' }}>No attendance found.</p>
                ) : (
                  selectedEventAttendance.map((a, idx) => (
                    <ParticipantCard key={idx}>
                      <p style={{ marginBottom: 8, color: '#2563eb', fontWeight: 600 }}>
                        <span style={{ color: '#334155' }}><strong>Name:</strong></span> {a.full_name}
                      </p>
                      <p style={{ margin: 0, color: '#334155' }}>
                        <strong>User ID:</strong> {a.user_id}
                      </p>
                      <p style={{ margin: 0, color: '#334155' }}>
                        <strong>Date:</strong> {a.timestamp}
                      </p>
                    </ParticipantCard>
                  ))
                )}
                <Button onClick={() => setAttendanceModal(false)} style={{ marginTop: '1.5rem', width: '100%' }}>
                  Close
                </Button>
              </ModalContent>
            </TopModal>
          )}

          {/* Sub-events Modal */}
          {subEventsModal && (
            <ParticipantModal onClick={() => setSubEventsModal(false)}>
              <ModalContent onClick={e => e.stopPropagation()} style={{ width: '95%', maxWidth: '800px' }}>
                <ModalTitle>🎯 Activities - {selectedSubEventsTitle}</ModalTitle>
                {selectedEventSubEvents.length === 0 ? (
                  <p style={{ color: '#64748b', textAlign: 'center', margin: '2rem 0' }}>No activities found.</p>
                ) : (
                  selectedEventSubEvents.map((sub, idx) => (
                    <ParticipantCard key={idx} style={{ marginBottom: '1rem' }}>
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <h4 style={{ fontSize: '1.1rem', fontWeight: '600', color: '#2563eb', marginBottom: '0.5rem' }}>
                          {sub.title}
                          <StatusBadge status={sub.status}>
                            {sub.status === 'upcoming' ? 'Upcoming' : 'Done'}
                          </StatusBadge>
                        </h4>
                        <p style={{ color: '#475569', marginBottom: '0.75rem' }}>{sub.description}</p>
                        <IconText><FaCalendarAlt /> {sub.date}</IconText>
                        <IconText><FaClock /> {sub.time}</IconText>
                        <IconText><FaMapMarkerAlt /> {sub.location}</IconText>
                        <IconText>
                          <strong style={{ color: '#2563eb' }}>Type:</strong> {sub.event_type}
                        </IconText>
                        <IconText>
                          <strong style={{ color: '#2563eb' }}>Points:</strong> {sub.points}
                        </IconText>

                        {/* Participant & attendance buttons */}
                        <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem' }}>
                          <Button onClick={() => handleSeeParticipants(sub)}>
                            <FaUsers /> See Participants
                          </Button>
                          <Button onClick={() => handleShowAttendance(sub)}>
                            📝 Show Attendance
                          </Button>
                        </div>
                      </div>
                    </ParticipantCard>

                  ))
                )}
                <Button onClick={() => setSubEventsModal(false)} style={{ marginTop: '1.5rem', width: '100%' }}>
                  Close
                </Button>
              </ModalContent>
            </ParticipantModal>
          )}
          {descriptionModal && (
          <DescriptionModalOverlay onClick={() => setDescriptionModal(false)}>
            <DescriptionModalContent onClick={(e) => e.stopPropagation()}>
              <DescriptionModalTitle>
                📝 Description - {selectedDescriptionTitle}
              </DescriptionModalTitle>
              <p style={{ color: '#334155', fontSize: '0.95rem', lineHeight: 1.6 }}>
                {selectedDescription}
              </p>
              <ModalButton
                onClick={() => setDescriptionModal(false)}
                style={{ marginTop: '1.5rem', width: '100%' }}
              >
                Close
              </ModalButton>
            </DescriptionModalContent>
          </DescriptionModalOverlay>
        )}
        </Main>
      </Container>
    </>
  );
};

export default Dashboard;
