import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import SidebarNav from '../components/Sidebar';
import { FaUser, FaMapMarkerAlt, FaPhone, FaGraduationCap, FaBriefcase, FaHeart, FaEye } from 'react-icons/fa';

const Layout = styled.div`
  display: flex;
  min-height: 100vh;
  background: ${({ dark }) => (dark ? '#18181b' : '#f3f5f9')};
  transition: background 0.3s;
`;

const PageWrapper = styled.div`
  margin-left: 240px; // Match sidebar width
  flex: 1;
  padding: 2rem;
  background: ${({ dark }) => (dark ? '#18181b' : '#f3f5f9')};
  min-height: 100vh;
  transition: background 0.3s;
`;

const Title = styled.h2`
  font-size: 1.5rem;
  color: #1f2937;
  font-weight: 700;
  margin-bottom: 1rem;
`;

const SearchBar = styled.input`
  padding: 0.5rem 1rem;
  margin-bottom: 1.5rem;
  border: 1px solid #d1d5db;
  border-radius: 0.5rem;
  font-size: 1rem;
  width: 100%;
  max-width: 350px;
  display: block;
`;

const Table = styled.table`
  width: 100%;
  background: white;
  border-collapse: collapse;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`;

const Thead = styled.thead`
  background: #3b82f6;
  color: white;

  th {
    padding: 0.75rem;
    font-size: 0.875rem;
    text-align: left;
    font-weight: 600;
  }
`;

const Tbody = styled.tbody`
  tr {
    border-bottom: 1px solid #e5e7eb;

    &:hover {
      background: #f9fafb;
    }
  }

  td {
    padding: 0.75rem;
    font-size: 0.875rem;
    color: #374151;
  }
`;

const Card = styled.div`
  background: white;
  border-radius: 0.5rem;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  transition: transform 0.2s;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  }
`;

const Section = styled.div`
  margin-bottom: 1rem;
  
  h3 {
    color: #3b82f6;
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`;

const Info = styled.p`
  color: #374151;
  font-size: 0.875rem;
  margin: 0.25rem 0;
`;

const Badge = styled.span`
  background: ${props => props.color || '#3b82f6'};
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
`;

const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: white;
  border-radius: 0.5rem;
  padding: 2rem;
  width: 90%;
  max-width: 800px;
  max-height: 85vh;
  overflow-y: auto;
  position: relative;
`;

const CloseButton = styled.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #6b7280;
  &:hover {
    color: #1f2937;
  }
`;

const ViewButton = styled.button`
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 0.375rem;
  padding: 0.5rem 1rem;
  font-size: 0.875rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  white-space: nowrap;
  
  &:hover {
    background: #2563eb;
  }
`;
const FilterBar = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
`;

const FilterButton = styled.button`
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  border: 1px solid #e5e7eb;
  background: ${props => props.active ? '#3b82f6' : 'white'};
  color: ${props => props.active ? 'white' : '#374151'};
  transition: all 0.2s;
  
  &:hover {
    background: ${props => props.active ? '#2563eb' : '#f9fafb'};
  }

  &:focus {
    outline: none;
    ring: 2px;
    ring-offset: 2px;
    ring-color: #3b82f6;
  }
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: center;
`;

const ActionButtonGroup = styled.div`
  display: flex;
  gap: 0.25rem;
`;

const ActionButton = styled.button`
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  border: none;
  background: ${props => props.variant === 'accept' ? '#059669' : '#dc2626'};
  color: white;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 0.5rem;

  &:hover {
    background: ${props => props.variant === 'accept' ? '#047857' : '#b91c1c'};
  }
`;

const YouthPage = () => {
  const [youths, setYouths] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedYouth, setSelectedYouth] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('skonnect_dark_mode');
    return saved === 'true';
  });

  const fetchYouths = async () => {
    try {
      const mainRes = await fetch("http://localhost/skonnect-api/youths.php");
      if (!mainRes.ok) throw new Error('Main server unreachable');
      const data = await mainRes.json();
      setYouths(data);
    } catch (err) {
      try {
        const fallbackRes = await fetch("http://localhost/skonnect-api/youths.php");
        const data = await fallbackRes.json();
        setYouths(data);
      } catch (fallbackErr) {
        console.error("Error loading youth data", fallbackErr);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchYouths();
  }, []);

  const handleStatusChange = async (youthId, newStatus) => {
    try {
      // If accepting, send the acceptance email first. Only update status when email send succeeds.
      if (newStatus === 'accepted') {
        const acceptedYouth = youths.find(y => y.id === youthId);

        if (!acceptedYouth || !acceptedYouth.email) {
          window.alert('Cannot accept: no email address available for this youth.');
          return;
        }

        try {
          // Note: using existing endpoint configured in this file. Make sure URL is correct (it looked like it might be missing a slash).
          const emailResp = await fetch(`https://vynceianoani.helioho.st/skonnect/send_acceptance.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: youthId, email: acceptedYouth.email, full_name: acceptedYouth.full_name })
          });

          // If request failed at network level
          if (!emailResp.ok) {
            console.error('Email endpoint returned non-OK status', emailResp.status);
            window.alert('Failed to send acceptance email. Status not changed.');
            return;
          }

          // Try parse JSON response; if it has success:false treat as failure
          let emailJson = null;
          try { emailJson = await emailResp.json(); } catch (e) { /* ignore parse errors */ }
          if (emailJson && emailJson.success === false) {
            console.error('Email endpoint reported failure:', emailJson);
            window.alert('Failed to send acceptance email. Status not changed.');
            return;
          }
        } catch (emailErr) {
          console.error('Error sending acceptance email:', emailErr);
          window.alert('Error sending acceptance email. Status not changed.');
          return;
        }
      }

      // Proceed to update status on server
      const response = await fetch(`http://localhost/skonnect-api/update_youth_status.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: youthId, status: newStatus })
      });

      if (response.ok) {
        // Update local state only after server accepted the change
        setYouths(youths.map(youth => (youth.id === youthId ? { ...youth, status: newStatus } : youth)));
      } else {
        console.error('Failed to update status on server:', response.status);
        window.alert('Failed to update status on server.');
      }
    } catch (error) {
      console.error('Error updating status:', error);
      window.alert('An error occurred while changing status.');
    }
  };

  const filteredYouths = youths.filter(youth => {
    const matchesSearch = Object.values(youth)
      .join(' ')
      .toLowerCase()
      .includes(search.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || youth.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <Layout dark={darkMode}>
      <SidebarNav darkMode={darkMode} />
      <PageWrapper dark={darkMode}>
        <Title>Youth Directory</Title>
        
        <FilterBar>
          <FilterButton 
            active={statusFilter === 'all'} 
            onClick={() => setStatusFilter('all')}
          >
            All
          </FilterButton>
          <FilterButton 
            active={statusFilter === 'pending'} 
            onClick={() => setStatusFilter('pending')}
          >
            Pending
          </FilterButton>
          <FilterButton 
            active={statusFilter === 'accepted'} 
            onClick={() => setStatusFilter('accepted')}
          >
            Accepted
          </FilterButton>
          <FilterButton 
            active={statusFilter === 'rejected'} 
            onClick={() => setStatusFilter('rejected')}
          >
            Rejected
          </FilterButton>
        </FilterBar>

        <SearchBar
          type="text"
          placeholder="Search youths..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        
        {loading ? (
          <p>Loading...</p>
        ) : (
          <Table>
            <Thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Address</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </Thead>
            <Tbody>
              {filteredYouths.map(youth => (
                <tr key={youth.id}>
                  <td>{youth.full_name}</td>
                  <td>{youth.contact}</td>
                  <td>{youth.email}</td>
                  <td>{youth.complete_address}</td>
                  <td>
                    <Badge color={
                      youth.status === 'accepted' ? '#059669' :
                      youth.status === 'rejected' ? '#dc2626' :
                      '#3b82f6'
                    }>
                      {youth.status || 'pending'}
                    </Badge>
                  </td>
                  <td>
                    <ActionButtons>
                      <ViewButton onClick={() => setSelectedYouth(youth)}>
                        <FaEye /> View
                      </ViewButton>
                      {youth.status === 'pending' && (
                        <ActionButtonGroup>
                          <ActionButton 
                            variant="accept"
                            onClick={() => handleStatusChange(youth.id, 'accepted')}
                            title="Accept youth registration"
                          >
                            Accept
                          </ActionButton>
                          <ActionButton 
                            variant="reject"
                            onClick={() => handleStatusChange(youth.id, 'rejected')}
                            title="Reject youth registration"
                          >
                            Reject
                          </ActionButton>
                        </ActionButtonGroup>
                      )}
                      {youth.status === 'rejected' && (
                        <ActionButton 
                          variant="accept"
                          onClick={() => handleStatusChange(youth.id, 'accepted')}
                          title="Move to accepted"
                        >
                          Move to Accepted
                        </ActionButton>
                      )}
                      {youth.status === 'accepted' && (
                        <ActionButton 
                          variant="reject"
                          onClick={() => handleStatusChange(youth.id, 'rejected')}
                          title="Move to rejected"
                        >
                          Move to Rejected
                        </ActionButton>
                      )}
                    </ActionButtons>
                  </td>
                </tr>
              ))}
            </Tbody>
          </Table>
        )}

        {selectedYouth && (
          <Modal onClick={() => setSelectedYouth(null)}>
            <ModalContent onClick={e => e.stopPropagation()}>
              <CloseButton onClick={() => setSelectedYouth(null)}>×</CloseButton>
              
              <Section>
                <h3><FaUser /> Personal Information</h3>
                <Info><strong>Name:</strong> {selectedYouth.full_name}</Info>
                <Info><strong>Birthdate:</strong> {selectedYouth.birthdate}</Info>
                <Info><strong>Birthplace:</strong> {selectedYouth.place_of_birth}</Info>
                <Info><strong>Gender:</strong> {selectedYouth.gender}</Info>
                <Info><strong>Interests:</strong> {selectedYouth.interests}</Info>
                <Info><strong>Civil Status:</strong> {selectedYouth.civil_status}</Info>
                <Info><strong>Religion:</strong> {selectedYouth.religion}</Info>
                <Info><strong>Blood Type:</strong> {selectedYouth.blood_type}</Info>
              </Section>

              <Section>
                <h3><FaPhone /> Contact Information</h3>
                <Info><strong>Primary Contact:</strong> {selectedYouth.contact}</Info>
                <Info><strong>Alternative Contact:</strong> {selectedYouth.alt_contact}</Info>
                <Info><strong>Email:</strong> {selectedYouth.email}</Info>
                <Info><strong>Facebook:</strong> {selectedYouth.facebook_account}</Info>
              </Section>

              <Section>
                <h3><FaMapMarkerAlt /> Address</h3>
                <Info>{selectedYouth.complete_address}</Info>
              </Section>

              <Section>
                <h3><FaGraduationCap /> Education & Employment</h3>
                <Info><strong>Education:</strong> {selectedYouth.educational_attainment}</Info>
                <Info><strong>Employment:</strong> {selectedYouth.employment_status}</Info>
                {selectedYouth.other_employment && (
                  <Info><strong>Other Employment:</strong> {selectedYouth.other_employment}</Info>
                )}
              </Section>

              <Section>
                <h3><FaBriefcase /> Youth Information</h3>
                <Info><strong>Classification:</strong> {selectedYouth.youth_classification}</Info>
                <Info><strong>Voter Status:</strong> {selectedYouth.voter_status}</Info>
                <Info><strong>Organizations:</strong> {selectedYouth.youth_organizations}</Info>
                <Info>
                  <strong>Vaccination Status:</strong> 
                  <Badge color={parseInt(selectedYouth.is_vaccinated) === 1 ? '#059669' : '#dc2626'}>
                    {parseInt(selectedYouth.is_vaccinated) === 1 ? 'Vaccinated' : 'Not Vaccinated'}
                  </Badge>
                </Info>
              </Section>

              <Section>
                <h3><FaHeart /> Emergency Contact</h3>
                <Info><strong>Name:</strong> {selectedYouth.emergency_contact_person}</Info>
                <Info><strong>Relationship:</strong> {selectedYouth.emergency_relationship}</Info>
                <Info><strong>Contact:</strong> {selectedYouth.emergency_contact}</Info>
                <Info><strong>Address:</strong> {selectedYouth.emergency_address}</Info>
              </Section>
            </ModalContent>
          </Modal>
        )}
      </PageWrapper>
    </Layout>
  );
};

export default YouthPage;
