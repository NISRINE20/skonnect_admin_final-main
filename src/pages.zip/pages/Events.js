import React, { useEffect, useState } from 'react';
import SidebarNav from '../components/Sidebar';
import { FaTrash } from 'react-icons/fa';
import {
  Layout,
  Container,
  Title,
  FormPanel,
  Form,
  InputGroup,
  Input,
  Select,
  Checkbox,
  TextArea,
  Button,
  DangerButton,
  FieldGroup,
} from '../styles/EventsStyles';
import styled from 'styled-components';

/* ---------------- Message Modal ---------------- */
const MessageModalOverlay = styled.div`
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(30, 41, 59, 0.18);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
`;

const MessageModalBox = styled.div`
  background: #fff;
  color: #18181b;
  border-radius: 1rem;
  padding: 2rem 2.5rem;
  box-shadow: 0 6px 32px rgba(99,102,241,0.15);
  text-align: center;
  min-width: 320px;
  font-weight: 600;
  border: 2px solid ${({ type }) => (type === 'error' ? '#f43f5e' : '#2563eb')};
`;

const MessageModalButton = styled.button`
  margin-top: 1.5rem;
  background: ${({ type }) => (type === 'error' ? '#f43f5e' : '#2563eb')};
  color: #fff;
  border: none;
  border-radius: 0.75rem;
  padding: 0.7rem 1.5rem;
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  box-shadow: 0 3px 12px rgba(99,102,241,0.15);
  transition: background 0.2s;
  &:hover { background: ${({ type }) => (type === 'error' ? '#dc2626' : '#1e40af')}; }
`;

const MessageText = styled.p`
  font-size: 1rem;
  margin: 0;
  color: ${({ type }) => (type === 'error' ? '#b91c1c' : '#1e3a8a')};
  font-weight: 600;
`;


/* ---------------- API Helper ---------------- */
const fetchWithFallback = async (urlPath, options = {}) => {
  const host = 'http://localhost/skonnect-api';
  const doFetch = async (hostUrl) => {
    const url = `${hostUrl}/${urlPath}`;
    const res = await fetch(url, options);
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); } catch { throw new Error('Invalid JSON response: ' + text); }
    if (!res.ok) throw new Error(json.message || text);
    return json;
  };
  return await doFetch(host);
};

/* ---------------- Component ---------------- */
const Events = () => {
  const [events, setEvents] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [message, setMessage] = useState(null);

  // Main Event Form
  const [mainForm, setMainForm] = useState({ title: '', description: '' });

  // Sub Event Form
  const [subEventInput, setSubEventInput] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    image: null,
    status: 'upcoming',
    points: '',
    event_type: 'General',
    customFields: []
  });
  const [subEvents, setSubEvents] = useState([]);
  const [subFieldInput, setSubFieldInput] = useState({ label: '', type: 'text', required: true });

  useEffect(() => { fetchEvents(); }, []);

const fetchEvents = async () => {
  try {
    const data = await fetchWithFallback('get_main_events.php');
    console.log('✅ Fetched main events:', data); 
    setEvents(data);
  } catch (err) {
    console.error('❌ Failed to fetch events', err);
  }
};


  /* ---------------- MAIN EVENT ---------------- */
  const handleCreateMainEvent = async (e) => {
    e.preventDefault();
    if (!mainForm.title || !mainForm.description) return;

    try {
      const result = await fetchWithFallback('create_main_event.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mainForm)
      });

      if (result.success && result.event_id) {
        setSelectedEventId(result.event_id);
        setMainForm({ title: '', description: '' });
        fetchEvents();
        setMessage({ type: 'success', text: 'Main event created successfully!' });
      } else {
        setMessage({ type: 'error', text: result.message || 'Failed to create event.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Error creating main event.' });
    }
  };

  /* ---------------- SUB EVENT ---------------- */
  const handleAddSubField = () => {
    if (!subFieldInput.label) return;
    setSubEventInput(prev => ({
      ...prev,
      customFields: [...prev.customFields, { ...subFieldInput, field_order: prev.customFields.length }]
    }));
    setSubFieldInput({ label: '', type: 'text', required: true });
  };

  const handleRemoveSubField = (i) => {
    setSubEventInput(prev => ({
      ...prev,
      customFields: prev.customFields.filter((_, idx) => idx !== i)
    }));
  };

  const handleAddSubEvent = () => {
    if (!subEventInput.title) return;
    setSubEvents(prev => [...prev, { ...subEventInput }]);
    setSubEventInput({
      title: '', description: '', date: '', time: '', location: '', image: null,
      status: 'upcoming', points: '', event_type: 'General', customFields: []
    });
  };

  const removeSubEvent = (i) => setSubEvents(prev => prev.filter((_, idx) => idx !== i));

  const handleSaveSubEvents = async () => {
    if (!selectedEventId) {
      setMessage({ type: 'error', text: 'Please create or select a main event first.' });
      return;
    } 

    try {
      const subForm = new FormData();
      subForm.append('event_id', selectedEventId);

      // include the currently-filled subEventInput directly when saving (no Add button)
      const finalSubEvents = [...subEvents];
      if (subEventInput.title) {
        finalSubEvents.push({ ...subEventInput });
      }

      const subeventsData = finalSubEvents.map(sub => ({
        title: sub.title,
        description: sub.description,
        date: sub.date,
        time: sub.time,
        location: sub.location,
        status: sub.status,
        points: sub.points,
        event_type: sub.event_type
      }));
      subForm.append('subevents', JSON.stringify(subeventsData));
      finalSubEvents.forEach((sub, idx) => {
        if (sub.image instanceof File) subForm.append(`image_${idx}`, sub.image);
      });

      const subResult = await fetchWithFallback('create_sub_event.php', { method: 'POST', body: subForm });
      console.log('[SubEvent Save Result]', subResult);

      if (subResult.success) {
        // Custom fields
        if (subResult.subevent_ids?.length > 0) {
          for (let i = 0; i < finalSubEvents.length; i++) {
            const subEvent = finalSubEvents[i];
            const subeventId = subResult.subevent_ids[i];
            for (const field of subEvent.customFields) {
              await fetchWithFallback('insert_subevent_field.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  subevent_id: subeventId,
                  label: field.label,
                  type: field.type,
                  required: field.required ? 1 : 0,
                  field_order: field.field_order
                })
              });
            }
          }
        }
        setSubEvents([]);
        // clear the current input as well after save
        setSubEventInput({
          title: '', description: '', date: '', time: '', location: '', image: null,
          status: 'upcoming', points: '', event_type: 'General', customFields: []
        });
        setMessage({ type: 'success', text: 'Sub-events saved successfully!' });
      } else {
        setMessage({ type: 'error', text: subResult.message || 'Failed to save sub-events.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Error saving sub-events.' });
    }
  };

  // --- Prevent selecting past dates/times ---
  const getTodayDate = () => new Date().toISOString().split('T')[0];
  const getCurrentTime = () => {
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
  };

  const [minDate, setMinDate] = useState(getTodayDate());
  const [minTime, setMinTime] = useState(getCurrentTime());

  // keep minDate/minTime updated (minTime updates every minute)
  useEffect(() => {
    const id = setInterval(() => {
      setMinDate(getTodayDate());
      setMinTime(getCurrentTime());
    }, 60 * 1000);
    return () => clearInterval(id);
  }, []);

  /* ---------------- JSX ---------------- */
  return (
    <Layout>
      <SidebarNav />
      <Container>
        <Title>📅 Create Events and Activities</Title>

        {/* ---------------- MAIN EVENT FORM ---------------- */}
        <FormPanel>
          <h3 style={{ color: '#2563eb' }}>Main Event</h3>
          <Form onSubmit={handleCreateMainEvent}>
            <InputGroup>
              <Input placeholder="Main Event Title" value={mainForm.title}
                onChange={e => setMainForm({ ...mainForm, title: e.target.value })} required />
            </InputGroup>
            <InputGroup style={{ flexBasis: '100%' }}>
              <TextArea rows="3" placeholder="Description" value={mainForm.description}
                onChange={e => setMainForm({ ...mainForm, description: e.target.value })} required />
            </InputGroup>
            <Button type="submit">💾 Save Main Event</Button>
          </Form>

        </FormPanel>

        {/* ---------------- SUB EVENT FORM ---------------- */}
        <FormPanel>
          <h3 style={{ color: '#16a34a' }}>Sub-events</h3>
          {/* Select Existing Event */}
          <div>
            <Select value={selectedEventId || ''} onChange={e => setSelectedEventId(e.target.value)}>
              <option value="">Select Existing Event</option>
              {events.map(ev => (
                <option key={ev.id} value={ev.id}>{ev.title}</option>
              ))}
            </Select>
          </div>
          <FieldGroup style={{ flexWrap: 'wrap' }}>
            <Input placeholder="Sub-event Title" value={subEventInput.title}
              onChange={e => setSubEventInput({ ...subEventInput, title: e.target.value })} />
            <Input placeholder="Description" value={subEventInput.description}
              onChange={e => setSubEventInput({ ...subEventInput, description: e.target.value })} />
            {/* date input: disallow past dates */}
            <Input
              type="date"
              value={subEventInput.date}
              min={minDate}
              onChange={e => {
                const newDate = e.target.value;
                setSubEventInput(prev => {
                  const updated = { ...prev, date: newDate };
                  // if choosing today ensure time is not in the past
                  if (newDate === minDate && prev.time && prev.time < minTime) {
                    updated.time = minTime;
                  }
                  return updated;
                });
              }}
            />
            {/* time input: if date === today, enforce min time */}
            <Input
              type="time"
              value={subEventInput.time}
              min={subEventInput.date === minDate ? minTime : undefined}
              onChange={e => {
                const t = e.target.value;
                if (subEventInput.date === minDate && t && t < minTime) {
                  // prevent selecting past time for today
                  setSubEventInput(prev => ({ ...prev, time: minTime }));
                } else {
                  setSubEventInput(prev => ({ ...prev, time: t }));
                }
              }}
            />
            <Input placeholder="Location" value={subEventInput.location}
              onChange={e => setSubEventInput({ ...subEventInput, location: e.target.value })} />
            <Select value={subEventInput.status} onChange={e => setSubEventInput({ ...subEventInput, status: e.target.value })}>
              <option value="upcoming">Upcoming</option>
              <option value="done">Done</option>
            </Select>
            <Select value={subEventInput.event_type}
              onChange={e => setSubEventInput({ ...subEventInput, event_type: e.target.value })}>
              <option value="General">General</option>
              <option value="Seminar">Seminar</option>
              <option value="Workshop">Workshop</option>
              <option value="Training">Training</option>
              <option value="Outreach">Outreach</option>
              <option value="Sports">Sports</option>
              <option value="Esports">Esports</option>
              <option value="Other">Other</option>
            </Select>
            <Input type="number" placeholder="Points" value={subEventInput.points}
              onChange={e => setSubEventInput({ ...subEventInput, points: e.target.value })} />
            <Input type="file" accept="image/*"
              onChange={e => setSubEventInput({ ...subEventInput, image: e.target.files[0] })} />
          </FieldGroup>

          {/* Custom Fields */}
          <h4 style={{ color: '#475569', marginTop: '1rem' }}>Sub-event Custom Fields</h4>
          <FieldGroup>
            <Input placeholder="Field Label" value={subFieldInput.label}
              onChange={e => setSubFieldInput({ ...subFieldInput, label: e.target.value })} />
            <Select value={subFieldInput.type} onChange={e => setSubFieldInput({ ...subFieldInput, type: e.target.value })}>
              <option value="text">Text</option>
              <option value="email">Email</option>
              <option value="number">Number</option>
              <option value="date">Date</option>
            </Select>

            {/* Removed the frontend "Required" checkbox — fields are required by default */}
            <Button type="button" onClick={handleAddSubField}>Add Field</Button>
          </FieldGroup>

          {subEventInput.customFields.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              {subEventInput.customFields.map((f, i) => (
                <FieldGroup key={i}>
                  <span>{f.label} ({f.type}) {f.required ? '*' : ''}</span>
                  <DangerButton type="button" onClick={() => handleRemoveSubField(i)}><FaTrash /></DangerButton>
                </FieldGroup>
              ))}
            </div>
          )}

          {subEvents.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              {subEvents.map((s, i) => (
                <FieldGroup key={i}>
                  <span>{s.title} — {s.date || '—'} — Points: {s.points || 0}</span>
                  <DangerButton type="button" onClick={() => removeSubEvent(i)}><FaTrash /></DangerButton>
                </FieldGroup>
              ))}
            </div>
          )}

          <Button type="button" onClick={handleSaveSubEvents}>💾 Save Sub-events</Button>
        </FormPanel>

        {/* Message Modal */}
        {message && (
           <MessageModalOverlay>
            <MessageModalBox type={message.type}>
              <MessageText type={message.type}>{message.text}</MessageText>
              <MessageModalButton
                type={message.type}
                onClick={() => setMessage(null)}
              >
                OK
              </MessageModalButton>
            </MessageModalBox>
          </MessageModalOverlay>
        )}
      </Container>
    </Layout>
  );
};

export default Events;
